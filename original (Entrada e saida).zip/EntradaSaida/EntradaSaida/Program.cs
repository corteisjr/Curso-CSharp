﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntradaSaida
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Gabriel");
            //Console.Write("Artigas");

            //int codigo = Console.Read();
            //Console.WriteLine(codigo);

            string texto = Console.ReadLine();
            Console.WriteLine(texto);

            Console.ReadKey();
        }
    }
}
